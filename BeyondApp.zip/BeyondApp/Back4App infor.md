# BeyondApp
BeyondList Back4app inför




1.Back4app login email and pw:
Email: zhengkunlian87@gmail.com
PW:BeyondList

2. Back4app account key: 

Name: BeyondList   Expires: Fri Apr 07 2023
Key: QugDMjA2WioEovNP7iAsppcg9wXTH1rKOQV4iHPb

3. Back4app App Id/Client Key: 
App Id
NAm07bM1LAHakJCwKp0JuUZrQc1ilbfLyRc5EY4T
Client Key
da5o4P2RGXXuJNHPiayUILv6e1YI6KoHQc1DR4VR
4. Update note:
Note about parse setting: 
https://guides.codepath.org/ios/Configuring-a-Parse-Server#2-setting-a-new-parse-server
?  Should we set the feature listed below?
(Optional) Adding Support for Live Queries

5. Help - Code references video link:
Create Tab Bar App with Navigation in Swift 5 (Xcode 11) - 2022 iOS


