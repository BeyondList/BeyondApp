//
//  DumpTaskViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/19/22.
//

import UIKit
import Parse

class DumpTaskViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var dumpTaskTableView: UITableView!
    var tasks = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dumpTaskTableView.delegate = self
        dumpTaskTableView.dataSource = self
        dumpTaskTableView.rowHeight = 127

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className: "Tasks")
        query.includeKey("author")
        query.limit = 10
        
        query.findObjectsInBackground{(tasks, error) in
            if tasks != nil {
                self.tasks = tasks!
                self.dumpTaskTableView.reloadData()
            }
        }
    

    // MARK: - Table view data source
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = dumpTaskTableView.dequeueReusableCell(withIdentifier: "TaskViewCell") as! TaskViewCell
        let task = tasks[indexPath.row]
        cell.taskNameLabel.text = task["name"] as! String
        cell.taskObjectId = task.objectId as! String
        cell.roundedView.layer.cornerRadius = cell .roundedView.frame.height / 8
        
        return cell
    }
    

    override func viewDidLayoutSubviews() {
       
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        
        let taskCell = tasks[indexPath.row]
        let objectIdToDelete = taskCell.objectId
        let query = PFQuery(className: "Tasks")
        
        do {
            let taskToDelete = try query.getObjectWithId(objectIdToDelete!)
            if editingStyle == .delete {
                tableView.beginUpdates()
                
                taskToDelete.deleteInBackground { (success, error) in
                    if success {
                        self.tasks.remove(at: indexPath.row)
                        tableView.deleteRows(at: [indexPath], with: .fade)
                        print("Deleted!")
                    } else {
                        print("error!")
                    }
                    
                }
            }
            tableView.endUpdates()
        } catch {
            print(error)
        }
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
   
    
    @IBAction func onBackButton(_ sender: Any) {
        
                 PFUser.logOut()
                 
                 let main = UIStoryboard(name: "Main", bundle: nil)
                 let TabBarViewController = main.instantiateViewController(withIdentifier: "TabBarViewController")
                 guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene, let delegate = windowScene.delegate as? SceneDelegate else {return}
                 
                 delegate.window?.rootViewController = TabBarViewController
                
                //dismiss(animated: true, completion: nil)
          
    }
}
