//
//  PhotoViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/16/22.
//

import UIKit
import Parse
import AlamofireImage

class PhotoViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var captionTextField: UITextField!
    @IBOutlet weak var photo: UIImageView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
    }
   
    @IBAction func onSubmit(_ sender: Any) {
        let profile = PFObject(className: "Profiles")
        
        profile ["caption"] = captionTextField.text!
        profile ["name"] = PFUser.current()!
        
      
        let photoData = photo.image!.pngData()
        let file = PFFileObject (name: "image.pgn", data: photoData!)
        PFUser.current()?.setObject(file!, forKey: "image")
        profile["image"] = file
        
    
        // Saves the new object.
        profile.saveInBackground {
          (success, error) in
          if (success) {
            // The object has been saved.
              //print("saved!")
              self.dismiss(animated: true, completion: nil)
              print("saved!")
          } else {
            // There was a problem, check error.description
              print ("error!")
          }
        }
    }
    
    //1.  tab the photo view and show the photo library
    @IBAction func onPhoto(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            picker.sourceType = .camera
        } else {
            picker.sourceType = .photoLibrary
        }
        
        present (picker, animated: true, completion: nil)
    }
    
    //to show photo
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let  image = info[.editedImage] as! UIImage
        let size = CGSize(width: 300, height: 300)
        let scaledImage = image.af.imageScaled(to: size)
        photo.image = scaledImage
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func onCancle(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
