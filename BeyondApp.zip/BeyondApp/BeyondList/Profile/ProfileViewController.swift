//
//  ProfileViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/16/22.
//

import UIKit
import Parse
import AlamofireImage

class ProfileViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate {
   
    
    @IBOutlet weak var profileView: UITableView!
    //.1 createa an object
    var profiles = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileView.delegate = self
        profileView.dataSource = self
        profileView.rowHeight = 230
    }
    
    //2 query data from parse
    override func  viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let  query = PFQuery(className: "Profiles")
        query.includeKey("name")
        query.limit = 1
        query.findObjectsInBackground{(profiles, error) in
            if profiles != nil {
                self.profiles = profiles!
                self.profileView.reloadData()
            }
        }
    }
  
    func tableView(_ tabelView: UITableView, numberOfRowsInSection senction: Int) -> Int {
       // return profiles.count
        return profiles.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = profileView.dequeueReusableCell(withIdentifier: "PhotoViewCell") as! PhotoViewCell
        let profile = profiles[indexPath.row]
        let user = profile["name"] as! PFUser
        cell.nameLabel.text = user.username as! String
        cell.captionLabel.text = profile["caption"] as! String
       //cell.photoView.layer.cornerRadius = cell.photoView.frame.height
      
        let imageFile = profile["image"] as! PFFileObject
        let urlString = imageFile.url!
        let url = URL(string: urlString)!
        cell.photo.af.setImage(withURL: url)
       
        return cell
    }

    @IBAction func onCancel(_ sender: Any) {
       
        
         PFUser.logOut()
         
         let main = UIStoryboard(name: "Main", bundle: nil)
         let TabBarViewController = main.instantiateViewController(withIdentifier: "TabBarViewController")
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene, let delegate = windowScene.delegate as? SceneDelegate else {return}
         
         delegate.window?.rootViewController = TabBarViewController
    }
    @IBAction func onEditButton(_ sender: Any) {
        
    }
}
