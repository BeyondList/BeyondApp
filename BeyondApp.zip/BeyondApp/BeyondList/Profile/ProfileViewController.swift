//
//  ProfileViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/16/22.
//

import UIKit
import Parse
import AlamofireImage

class ProfileViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate {
   
    
    @IBOutlet weak var profileView: UITableView!
    //.1 createa an object
    var profiles = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileView.delegate = self
        profileView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    //2 query data from parse
    override func  viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let  query = PFQuery(className: "Profiles")
        query.includeKey("name")
        query.limit = 3
        query.findObjectsInBackground{(profiles, error) in
            if profiles != nil {
                self.profiles = profiles!
                self.profileView.reloadData()
            }
        }
        
    }
       /*
        query.findObjectsInBackground { (profiles: [PFObject]?, error:Error?) in
            if let error = error {
                print(error.localizedDescription)
            } else if let profiles = profiles {
                print("Successfully retrieved \(profiles.count)scores.")
                for profile in profiles {
                    print(profile.objectId as Any)
                }
            }
            
        }
        */
     
        

  
    func tableView(_ tabelView: UITableView, numberOfRowsInSection senction: Int) -> Int {
       // return profiles.count
        return profiles.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = profileView.dequeueReusableCell(withIdentifier: "PhotoViewCell") as! PhotoViewCell
       
        let profile = profiles[indexPath.row]
        
        let user = profile["name"] as! PFUser
        cell.nameLabel.text = user.username as! String
        cell.captionLabel.text = profile["caption"] as! String
        
      /*
        let imageFile = profile["image"] as! PFFileObject
        let urlString = imageFile.url!
        let url = URL(string: urlString)!
        cell.photo.af.setImage(withURL: url)
       */
        return cell
    }
    



    @IBAction func onCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func onEditButton(_ sender: Any) {
        
    }
}
