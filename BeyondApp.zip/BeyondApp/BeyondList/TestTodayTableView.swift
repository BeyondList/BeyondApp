//
//  TestTodayTableView.swift
//  BeyondList
//
//  Created by Mark on 4/10/22.
//

import UIKit
import Parse

class TestTodayTableView: UITableView {
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
