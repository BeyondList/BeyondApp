//
//  TomorrowTaskTableViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/6/22.
//

import UIKit
import Parse

class TomorrowTaskViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
     @IBOutlet weak var tomorrowTaskTableView: UITableView!
     var tasks = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tomorrowTaskTableView.delegate = self
        tomorrowTaskTableView.dataSource = self
        tomorrowTaskTableView.rowHeight = 127

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className: "Tasks")
        query.includeKey("author")// should a tomorrow column be created for Tomorrow task display?
        query.limit = 10
        
        query.findObjectsInBackground{(tasks, error) in
            if tasks != nil {
                self.tasks = tasks!
                self.tomorrowTaskTableView.reloadData()
            }
        }
    

    // MARK: - Table view data source
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tomorrowTaskTableView.dequeueReusableCell(withIdentifier: "TaskViewCell") as! TaskViewCell
        let task = tasks[indexPath.row]
        cell.taskNameLabel.text = task["name"] as! String
        cell.taskObjectId = task.objectId as! String
        cell.roundedView.layer.cornerRadius = cell .roundedView.frame.height / 8
        
        return cell
    }
    
    
    @IBAction func onBackButton(_ sender: Any) {
       
           
            
             PFUser.logOut()
             
             let main = UIStoryboard(name: "Main", bundle: nil)
             let TabBarViewController = main.instantiateViewController(withIdentifier: "TabBarViewController")
             guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene, let delegate = windowScene.delegate as? SceneDelegate else {return}
             
             delegate.window?.rootViewController = TabBarViewController
            
            //dismiss(animated: true, completion: nil)
        
    }
    
}
