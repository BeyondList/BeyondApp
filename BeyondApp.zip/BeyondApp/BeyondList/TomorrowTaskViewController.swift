//
//  TomorrowTaskTableViewController.swift
//  BeyondList
//
//  Created by 07elenazheng-@naver.com on 4/6/22.
//

import UIKit
import Parse

class TomorrowTaskViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
     @IBOutlet weak var tomorrowTaskTableView: UITableView!
     var tasks = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tomorrowTaskTableView.delegate = self
        tomorrowTaskTableView.dataSource = self
        tomorrowTaskTableView.rowHeight = 127

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className: "Tasks")
        query.includeKey("author")// should a tomorrow column be created for Tomorrow task display?
        query.limit = 10
        
        query.findObjectsInBackground{(tasks, error) in
            if tasks != nil {
                self.tasks = tasks!
                self.tomorrowTaskTableView.reloadData()
            }
        }
    

    // MARK: - Table view data source
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tomorrowTaskTableView.dequeueReusableCell(withIdentifier: "TaskViewCell") as! TaskViewCell
        let task = tasks[indexPath.row]
        cell.taskNameLabel.text = task["name"] as! String
        cell.taskObjectId = task.objectId as! String
        cell.roundedView.layer.cornerRadius = cell .roundedView.frame.height / 8
        
        return cell
    }
    // reorder the tasks
    override  func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        <#code#>
    }
    /*
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let taskSeleted = tasks [indexPath.row]
        let editingMessage = UIAlertController(title: "Edit", message: "Edit Name of Task", preferredStyle: .alert)
        let update = UIAlertAction(title: "Update", style: .default){
            (action) in
            let updatedTask = self.tasks.text
            self.tasks[indexPath.row] = updatedTask
            
            DispatchQueue.main.async{
                self.tomorrowTaskTableView.reloadData()
                print("Data has been updated.")
            }
            editingMessage.addAction(update)
            editingMessage.addAction(cancel)
            editingMessage.addTextField{(textfield) in
                self.tasks = textfield
                self.tasks?.placeholder = "Update task here."
                self.tasks?.text = taskSeleted
        }
            
            self.present(editingMessage, animated: true, completion: nil)
            
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            print("Edit cancelled.")
    }
        }
        */
    
    
    @IBAction func onBackButton(_ sender: Any) {
    
             PFUser.logOut()
             
             let main = UIStoryboard(name: "Main", bundle: nil)
             let TabBarViewController = main.instantiateViewController(withIdentifier: "TabBarViewController")
             guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene, let delegate = windowScene.delegate as? SceneDelegate else {return}
             
             delegate.window?.rootViewController = TabBarViewController
            
    }
    
   
  
}
/*
 //1.  tab the photo view and show the photo library
 @IBAction func onPhoto(_ sender: Any) {
     let picker = UIImagePickerController()
     picker.delegate = self
     picker.allowsEditing = true
     
     if UIImagePickerController.isSourceTypeAvailable(.camera){
         picker.sourceType = .camera
     } else {
         picker.sourceType = .photoLibrary
     }
     
     present (picker, animated: true, completion: nil)
 }
 
 //to show photo
 func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
     let  image = info[.editedImage] as! UIImage
     let size = CGSize(width: 300, height: 300)
     let scaledImage = image.af.imageScaled(to: size)
     photo.image = scaledImage
     dismiss(animated: true, completion: nil)
     
 }
 */
